#!/bin/bash

# Function to count files in the current directory
count_files() {
  echo $(ls -1 | wc -l)
}

# Main guessing game logic
correct_count=$(count_files)

echo "Welcome to the Guessing Game!"

while true; do
  echo "How many files are in the current directory?"
  read guess

  if [[ ! $guess =~ ^[0-9]+$ ]]; then
    echo "Please enter a valid number."
    continue
  fi

  if [[ $guess -lt $correct_count ]]; then
    echo "Too low! Try again."
  elif [[ $guess -gt $correct_count ]]; then
    echo "Too high! Try again."
  else
    echo "Congratulations! You guessed it right."
    break
  fi
done
